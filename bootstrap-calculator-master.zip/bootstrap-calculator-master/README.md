# bootstrap-calculator
Simple calculator build with JS and bootstrap

You can demo it here: http://dev.mensfeld.pl/bootstrap-calculator/index.html
